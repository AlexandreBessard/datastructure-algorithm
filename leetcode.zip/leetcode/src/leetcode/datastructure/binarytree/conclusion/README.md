<p>Check the website below: </p>
https://leetcode.com/explore/learn/card/data-structure-tree/133/conclusion/

