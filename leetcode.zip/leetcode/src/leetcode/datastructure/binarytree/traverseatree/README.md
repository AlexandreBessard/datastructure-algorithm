Inorder:  
Left -> node -> right

Postorder:
Left -> right -> node

Preorder:
Node -> left -> right


Memorize technique:

