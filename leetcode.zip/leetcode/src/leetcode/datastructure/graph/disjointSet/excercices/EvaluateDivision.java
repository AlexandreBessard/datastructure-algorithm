package leetcode.datastructure.graph.disjointSet.excercices;

import java.util.List;

//TODO: Can be difficult, need to understand.
public class EvaluateDivision {

    public static void main(String[] args) {

    }

    public double[] calcEquation(List<List<String>> equations, double[] values, List<List<String>> queries) {

        return new double[0];
    }
}
