package leetcode.datastructure.binarysearch;

//https://leetcode.com/explore/learn/card/binary-search/138/background/1038/
public class BinarySearch {

    public static void main(String[] args) {

        int[] array = {-1,0,3,5,9,12};
        //Output: 9
        System.out.println(new BinarySearch().search(array, 9));
    }

    /*
    Time complexity: O(logN): The equation represents dividing a problem up into
    a subproblems.
    Space complexity: O(1) constant space solution
     */
    public int search(int[] nums, int target) {
        int left = 0, right = nums.length - 1;
        int pivot;
        while(left <= right) {
            pivot = left + (right - left) / 2;
            if(nums[pivot] == target) return pivot;
            if(nums[pivot] > target) right = pivot - 1;
            else left = pivot + 1;
        }
        return -1;
    }
}
