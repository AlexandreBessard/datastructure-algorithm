package leetcode.datastructure.binarysearch.conclusion;

//https://leetcode.com/explore/learn/card/binary-search/137/conclusion/982/
public class Pow {

    public static void main(String[] args) {
        double x = 2.00000;
        int n = 10;
        System.out.println(new Pow().myPow(x, n));
    }

    public double myPow(double x, int n) {

        return 0.0;
    }
}
