package topinterviewquestions.easy.array;

//https://leetcode.com/explore/featured/card/top-interview-questions-easy/92/array/646/
public class RotateArray {

    public static void main(String[] args) {
        int[] array = {1,2,3,4,5,6,7};
        new RotateArray().rotate(array, 5);
    }

    //Approach 4: using reverse
    public void rotate(int[] nums, int k) {
        System.out.println(5 % 2);

    }
}
